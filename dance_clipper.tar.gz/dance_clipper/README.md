# 🎬 舞蹈视频智能剪辑系统

将长舞蹈视频按照音乐结构和动作连贯性智能缩编为指定时长的短视频。

## ✨ 核心特性

- **音乐结构感知**：在乐句边界剪辑，保持音乐完整性
- **动作连贯性检测**：避免在跳跃/旋转中间切断
- **节拍对齐**：自动对齐到强拍，保证剪辑点自然
- **多段智能拼接**：支持多片段组合，精确控制时长

## 📦 安装

### 系统依赖

需要安装 FFmpeg（必需）和 Python 3.8+：

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install ffmpeg

# macOS
brew install ffmpeg

# Windows
# 下载并安装: https://ffmpeg.org/download.html
```

### Python 依赖

```bash
cd dance_clipper
pip install -r requirements.txt
```

主要依赖：
- `librosa` - 专业音频分析
- `numpy` - 数值计算
- `pyyaml` - 配置文件解析
- `pillow` - 图像处理（可选，用于动作分析）

## 🚀 快速开始

### 1. 基本使用

```bash
python dance_clipper.py input_video.mp4 -o output.mp4 -t 30
```

参数说明：
- `input_video.mp4` - 输入的长舞蹈视频
- `-o output.mp4` - 输出路径（默认为 output_clip.mp4）
- `-t 30` - 目标时长30秒（默认30秒）
- `--tolerance 2` - 时长容差2秒（默认2秒）

### 2. 使用配置文件

```bash
python dance_clipper.py input_video.mp4 --config config.yaml
```

## 📋 完整示例

### 示例1：将5分钟舞蹈视频压缩到15秒（适合抖音）

```bash
python dance_clipper.py long_dance.mp4 -o short_dance.mp4 -t 15 --tolerance 1
```

输出报告示例：
```json
{
  "input_file": "long_dance.mp4",
  "output_file": "short_dance.mp4",
  "original_duration": 300.5,
  "output_duration": 15.2,
  "target_duration": 15.0,
  "segments": [
    {
      "start": "45.50s",
      "end": "60.70s",
      "duration": "15.20s",
      "music_score": "0.95",
      "motion_score": "0.82"
    }
  ],
  "compression_ratio": "19.8x"
}
```

### 示例2：批量处理多个视频

```bash
# 创建批量处理脚本
for video in *.mp4; do
    python dance_clipper.py "$video" -o "clips/${video%.mp4}_clip.mp4" -t 30
done
```

### 示例3：Python API 调用

```python
from dance_clipper import DanceClipper, ClipConfig

# 创建配置
config = ClipConfig(
    target_duration=30.0,
    tolerance=2.0,
    min_segment_duration=4.0,
    audio_weight=0.6,  # 重视音乐结构
    video_weight=0.4   # 兼顾动作连贯
)

# 创建剪辑器
clipper = DanceClipper(config)

# 执行剪辑
report = clipper.clip("input.mp4", "output.mp4")

print(f"原始时长: {report['original_duration']:.1f}s")
print(f"输出时长: {report['output_duration']:.1f}s")
print(f"压缩比: {report['compression_ratio']}")
```

## 🔬 独立模块使用

### 音频分析

```python
from audio_analyzer import AudioAnalyzer

analyzer = AudioAnalyzer()
analysis = analyzer.analyze("audio.wav")

print(f"BPM: {analysis.bpm}")
print(f"乐句数: {len(analysis.phrases)}")

# 可视化分析结果
analyzer.visualize("audio.wav", "analysis.png")
```

### 视频分析

```python
from video_analyzer import VideoAnalyzer

analyzer = VideoAnalyzer()
analysis = analyzer.analyze("video.mp4")

# 获取动作得分最高的30秒片段
best_segments = analyzer.find_best_segments(analysis, target_duration=30)
for start, end, score in best_segments[:3]:
    print(f"{start:.1f}s - {end:.1f}s (得分: {score:.3f})")
```

## ⚙️ 配置详解

编辑 `config.yaml` 自定义剪辑行为：

```yaml
# 目标时长设置
target_duration: 30.0      # 输出视频时长（秒）
tolerance: 2.0             # 允许误差（±2秒）

# 音频权重 vs 视频权重
# 和为1，音频权重高则更注重音乐结构
audio:
  weight: 0.6

video:
  weight: 0.4
  
# 最小片段时长
min_segment_duration: 4.0  # 每段至少4秒，避免太短
```

## 🎯 针对不同场景的推荐配置

### 抖音/快手短视频（15秒）
```yaml
target_duration: 15.0
tolerance: 1.0
min_segment_duration: 3.0
max_segments: 1  # 单一片段，不拼接
```

### 小红书/B站短视频（30-60秒）
```yaml
target_duration: 30.0
tolerance: 2.0
min_segment_duration: 4.0
max_segments: 2  # 允许两段拼接
```

### 舞蹈教学精华版（60-120秒）
```yaml
target_duration: 90.0
tolerance: 5.0
min_segment_duration: 8.0  # 较长片段，展示完整动作
max_segments: 3
```

## 🔍 工作原理

```
输入视频
    │
    ▼
┌─────────────────┐
│  1. 音频分析层   │  → BPM检测、节拍跟踪、乐句分割
│  (Librosa)      │
└─────────────────┘
    │
    ▼
┌─────────────────┐
│  2. 视频分析层   │  → 动作密度、场景切换检测
│  (FFmpeg/OpenCV)│
└─────────────────┘
    │
    ▼
┌─────────────────┐
│  3. 智能剪辑引擎 │  → 在乐句边界选择最优片段
│                 │     保证音乐结构 + 动作连贯
└─────────────────┘
    │
    ▼
输出短视频
```

## 🐛 故障排除

### 问题1："ffmpeg not found"
**解决**：确保 FFmpeg 已安装并在 PATH 中
```bash
which ffmpeg  # Linux/Mac
where ffmpeg  # Windows
```

### 问题2："No module named 'librosa'"
**解决**：安装 Python 依赖
```bash
pip install librosa numpy pyyaml
```

### 问题3：剪辑后音乐听起来不连贯
**解决**：降低 `tolerance` 值，增加 `min_segment_duration`，或调高 `audio_weight`

### 问题4：输出时长与目标偏差较大
**解决**：
- 确保原视频时长足够长
- 检查 `max_segments` 是否设置得太小
- 增大 `tolerance` 值

## 📊 性能参考

在普通笔记本（Intel i5, 16GB RAM）上的处理速度：

| 视频时长 | 分辨率 | 处理时间 |
|---------|-------|---------|
| 5分钟 | 1080p | ~30秒 |
| 15分钟 | 1080p | ~90秒 |
| 30分钟 | 4K | ~5分钟 |

## 📝 更新计划

- [ ] 支持 GPU 加速（CUDA）
- [ ] 添加 Web 界面
- [ ] 支持实时预览
- [ ] 添加更多舞蹈类型预设（芭蕾、街舞、民族舞等）

## 📄 许可

MIT License

---

**有问题或建议？** 欢迎提交 Issue 或 PR。
